# Assignment-5
Building a Database with Binary Search Trees

referenced:
http://www.cplusplus.com/doc/tutorial/files/
https://stackoverflow.com/questions/19761069/opening-a-file-in-the-current-directory
http://www.cplusplus.com/reference/string/string/substr/
https://stackoverflow.com/questions/14743904/stdstoi-missing-in-g-4-7-2
